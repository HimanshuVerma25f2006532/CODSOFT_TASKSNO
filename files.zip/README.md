# CODSOFT_TASKSNO

Python tasks for the CODSOFT internship.

| Task | File | Description |
|------|------|-------------|
| 1 | `task1_todo.py` | Command-line to-do list (add, view, update, mark done, delete; saved to JSON) |
| 2 | `task2_calculator.py` | Calculator with basic arithmetic |
| 3 | `task3_password_generator.py` | Random password generator with length and complexity options |
| 4 | `task4_rock_paper_scissors.py` | Rock-Paper-Scissors vs. computer with score tracking |
| 5 | `task5_contact_book.py` | Contact book (add, view, search, update, delete; saved to JSON) |

## Run
```
python task1_todo.py
```
Requires Python 3.8+. No external libraries.
